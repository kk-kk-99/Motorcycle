#include "KEY.h"
#include "zf_common_headfile.h"


extern int tiaobian;
int keyflag[6]={0},shunxu[]={0,0,0,0,2,0,0,1,0,4,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
//shunxu[]={0,0,0,5,4,3,8,0,0,0,9,0,0,1,2,7,0,0,0,0,0,0,0,0,0,6,0,0,0,0,0,0,0,0,0,0}����˫���
//shunxu[]={0,0,0,5,4,3,8,0,0,0,9,6,0,1,2,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}�����ȵ��
//shunxu[]={0,0,0,0,4,3,8,0,0,0,9,0,0,1,2,7,0,0,0,0,0,0,0,0,0,5,6,0,0,0,0,0,0,0,0,0};
//shunxu[]={0,0,0,2,0,1,0,0,0,5,0,3,4,0,0,0,0,0,0,0,0,0,0,0,0,5,6,0,0,0,0,0,0,0,0,0};˳�ǵ�Ŷ�·
//0,0,0,2,4,1,7,0,0,8,0,0,0,0,3,0,0,5,0,0,0,0,0,0,0,0,6,0,0,0,0,0,0,0,0,0
//0,0,0,2,0,1,0,0,0,5,0,3,4,0,0,0,0,0,0,0,0,0,0,0,0,5,6,0,0,0,0,0,0,0,0,0
//0,0,0,2,4,1,6,0,0,9,0,0,0,0,3,0,0,5,0,0,0,8,0,0,0,0,7,0,0,0,0,0,0,0,0,0�ޱ���
int speedset=600,
    jiasuspeed=0,
    keycai=0,
    keyrow=0,
    jiaflag=0,
    jianflag=0,
    key1flag=0,
    clearflag=0,
    saidaoshunxu=0,
    keythreshold=111,

    anspeed=-100;
float scales=0.1;
extern int facheflag;
void keycaidan()//��tft��ʾ���п���
{
    ips200_show_float(1*8,14*16,chazhi,3,2);
    ips200_show_int(1*8,13*16,tiaobian,1);
    ips200_show_int(1*8,12*16,facheflag,1);

    switch (keycai)
{

    case 0:
        menu0();
       menu0aim();
        break;
    case 1:
        menu1();
        menu1aim();
        break;
    case 2:
       menu2();
       menu2aim();
        break;
    case 3:
       // menu3();
       // menu3aim();
        break;
        default:
        break;
}
    if (key_get_state(KEY_1) == KEY_SHORT_PRESS)
         {
             keyflag[1] = 1;
         }
         else if(key_get_state(KEY_1) == KEY_LONG_PRESS)
         {
             keyflag[1] = 2;
             ips200_show_string(15*8,0*16,"1");
         }
         else if (key_get_state(KEY_1) == KEY_RELEASE)
         {
             if (keyflag[1]==1)
             {
                 keyrow--;
                 if(keyrow<0)
                 {
                     keyrow=9;
                 }
                 clearflag=0;
                 keyflag[1] = 0;
             }
         }
   if (key_get_state(KEY_2) == KEY_SHORT_PRESS)
                {
                    keyflag[2] = 1;
                }
                else if(key_get_state(KEY_2) == KEY_LONG_PRESS)
                {
                    keyflag[2] = 2;
                    ips200_show_string(15*8,0*16,"2");
                }
                else if (key_get_state(KEY_2) == KEY_RELEASE)
                {
                    if( keyflag[2] == 1)
                    {
                        keyrow++;
                        clearflag=0;
                    }
                    keyflag[2] = 0;
                }
    if (key_get_state(KEY_3) == KEY_SHORT_PRESS)
        {
            keyflag[3] = 1;
        }
        else if(key_get_state(KEY_3) == KEY_LONG_PRESS)
        {
            keyflag[3] = 2;
            ips200_show_string(15*8,0*16,"3");
        }
        else if (key_get_state(KEY_3) == KEY_RELEASE)
        {
            if (keyflag[3]==1)
            {
                jiaflag=1;
                clearflag=0;
            }
            keyflag[3] = 0;
        }
    if (key_get_state(KEY_4) == KEY_SHORT_PRESS)
    {
        keyflag[4] = 1;
    }
    else if(key_get_state(KEY_4) == KEY_LONG_PRESS)
    {
        keyflag[4] = 2;
        ips200_show_string(15*8,0*16,"4");
    }
    else if (key_get_state(KEY_4) == KEY_RELEASE)
    {
        if( keyflag[4] == 1)//�̰�ִ�д���
        {
            clearflag=0;
            jianflag=1;
        }
        keyflag[4] = 0;
        }
//�˵�ҳ��ѡ��
        if (key_get_state(KEY_5) == KEY_SHORT_PRESS)
          {
            keyflag[5] = 1;

          }
        else if(key_get_state(KEY_5) == KEY_LONG_PRESS)
        {
            keyflag[5] = 2;
            ips200_show_string(15*8,0*16,"5");
        }
        else if (key_get_state(KEY_5) == KEY_RELEASE)
           {
            if( keyflag[5] == 1)//�̰�ִ�д���
            {
                clearflag=0;
            }
            keyflag[5] = 0;
           }

}
void menu0()
{
    tftclead();
    if (keyrow<=9)
        {
        ips200_show_string(0*8,keyrow*16,">");
        ips200_show_string(2*8,0*16,"gp");
        ips200_show_string(2*8,1*16,"ap");
        ips200_show_string(2*8,2*16,"sp");
        ips200_show_string(2*8,3*16,"sc");
        ips200_show_string(2*8,4*16,"gi");
        ips200_show_string(2*8,5*16,"gd");
        ips200_show_string(2*8,6*16,"ai");
        ips200_show_string(2*8,7*16,"si");
        ips200_show_string(2*8,8*16,"ro");

//        tft180_show_string(6*8,0,"speedpid");
//        tft180_show_string(2*8,2*16,"ki");
//        tft180_show_string(2*8,3*16,"kd");
       // tft180_show_string(6*8,4*16,"anglepid");
//        tft180_show_string(2*8,5*16,"kp");
//        tft180_show_string(2*8,6*16,"ki");
//        tft180_show_string(2*8,7*16,"kd");
//        tft180_show_string(2*8,8*16,"speed:");
        ips200_show_float(8*8, 0*16, pid2.gyro_P, 3,2);
        ips200_show_float(8*8, 1*16, pid2.angle_p, 3,2);
        ips200_show_float(8*8, 2*16, pid2.speed_p, 3,2);
        ips200_show_float(8*8, 3*16, scales, 3,2);
        ips200_show_float(8*8, 4*16, pid2.gyro_i,3,2);
        ips200_show_float(8*8, 5*16, pid2.velo_p, 3,2);
        ips200_show_float(8*8, 6*16, pid2.velo_i, 3,2);
        ips200_show_float(8*8, 7*16, pid2.speed_I,3,2);
//        ips200_show_float(8*8, 8*16, pid2.speed_I, 3,3);
        ips200_show_float(0*8, 9*16, imu.pitch, 3,2);
//        tft180_show_int(8*8, 7*16, shunxu[7], 2);
//        tft180_show_int(8*8, 8*16, shunxu[8], 2);

//        tft180_show_string(2*8,0*16,"pitch:");
//        tft180_show_string(2*8,1*16,"roll:");

//        tft180_show_string(2*8,3*16,"tp:");
//        tft180_show_string(2*8,4*16,"ti:");
//        tft180_show_string(2*8,5*16,"td:");
//        tft180_show_string(2*8,6*16,"yp1:");
//        tft180_show_string(2*8,7*16,"yp2:");

        }
    else if(keyrow>=9&&keyrow<=17)
    {
        ips200_show_int(6*8, 0*16, speed1, 2);
        ips200_show_int(6*8, 1*16, speed2, 2);
        ips200_show_float(6*8, 2*16, imu.roll, 3,2);
        ips200_show_float(6*8, 3*16, imu.pitch, 3,2);
        ips200_show_int(6*8, 4*16, shunxu[13], 2);
        ips200_show_int(6*8, 5*16, shunxu[14], 2);
        ips200_show_int(6*8, 6*16, shunxu[15], 2);
        ips200_show_int(6*8, 7*16, shunxu[16], 2);
        ips200_show_int(6*8, 8*16, shunxu[17], 2);
        ips200_show_string(0*8,(keyrow-9)*16,">");
        ips200_show_string(2*8,0*16,"sp1");
        ips200_show_string(2*8,1*16,"sp2");
        ips200_show_string(2*8,2*16,"rol");
        ips200_show_string(2*8,3*16,"pit");
        ips200_show_string(2*8,4*16,"Ldh:");
        ips200_show_string(2*8,5*16,"DLd:");
        ips200_show_string(2*8,6*16,"rco:");
        ips200_show_string(2*8,7*16,"rco:");
        ips200_show_string(2*8,8*16,"lco:");
    }
    else if(keyrow>=18&&keyrow<=26)
    {
        ips200_show_int(6*8, 0*16, shunxu[18], 2);
        ips200_show_int(6*8, 1*16, shunxu[19], 2);
        ips200_show_int(6*8, 2*16, shunxu[20], 2);
        ips200_show_int(6*8, 3*16, shunxu[21], 2);
        ips200_show_int(6*8, 4*16, shunxu[22], 2);
        ips200_show_int(6*8, 5*16, shunxu[23], 2);
        ips200_show_int(6*8, 6*16, shunxu[24], 2);
        ips200_show_int(6*8, 7*16, shunxu[25], 2);
        ips200_show_int(6*8, 8*16, shunxu[26], 2);
        ips200_show_string(0*8,(keyrow-18)*16,">");
        ips200_show_string(2*8,0*16,"lco:");
        ips200_show_string(2*8,1*16,"zb:");
        ips200_show_string(2*8,2*16,"yb:");
        ips200_show_string(2*8,3*16,"Rdh:");
        ips200_show_string(2*8,4*16,"Ldh:");
        ips200_show_string(2*8,5*16,"rri:");
        ips200_show_string(2*8,6*16,"lri:");
        ips200_show_string(2*8,7*16,"SDL:");
        ips200_show_string(2*8,8*16,"DLd:");
    }
    else if(keyrow>=27&&keyrow<=36)
      {
        ips200_show_int(6*8, 0*16, shunxu[27], 2);
        ips200_show_int(6*8, 1*16, shunxu[28], 2);
        ips200_show_int(6*8, 2*16, shunxu[29], 2);
        ips200_show_int(6*8, 3*16, shunxu[30], 2);
        ips200_show_int(6*8, 4*16, shunxu[31], 2);
          ips200_show_string(0*8,(keyrow-27)*16,">");
          ips200_show_string(2*8,0*16,"SDR:");
          ips200_show_string(2*8,1*16,"kzh");
          ips200_show_string(2*8,2*16,"kzh");
          ips200_show_string(2*8,3*16,"kZB");
          ips200_show_string(2*8,4*16,"kYB");
      }
}
void menu0aim()
{if(keyrow<=9)
{
    switch(keyrow)
    {

        case 0:
            if(jianflag==1)
            {
                pid2.gyro_P-=scales;
                jianflag=0;
            }else if(jiaflag==1)
            {
                pid2.gyro_P+=scales;
                jiaflag=0;
            }
            break;
        case 1:
            if(jianflag==1)
            {
                pid2.angle_p-=scales;
                jianflag=0;
            }
            else if(jiaflag==1)
            {
                pid2.angle_p+=scales;
                jiaflag=0;
            }
            break;
        case 2:
              if(jianflag==1)
              {
                  pid2.speed_p-=scales;
                  jianflag=0;
              }
              else if(jiaflag==1)
              {
                  pid2.speed_p+=scales;
                  jiaflag=0;
              }
              break;
        case 3:
            if(jianflag==1)
            {
                scales=scales*10;
                if(scales>100)
                {
                    scales=0.01;
                }
                jianflag=0;
            }
            else if(jiaflag==1)
            {
                scales=scales*10;
                if(scales>100)
                {
                    scales=0.1;
                }
                jiaflag=0;
            }
            break;
        case 4:
              if(jianflag==1)
              {
                  pid2.gyro_i-=scales;
                  jianflag=0;
              }
              else if(jiaflag==1)
              {
                  pid2.gyro_i+=scales;
                  jiaflag=0;
              }break;
        case 5:
              if(jianflag==1)
              {
                  pid2.velo_p-=scales;
                  jianflag=0;
              }
              else if(jiaflag==1)
              {
                  pid2.velo_p+=scales;
                  jiaflag=0;
              }break;
        case 6:
                  if(jianflag==1)
                  {
                      pid2.velo_i-=scales;
                      jianflag=0;
                  }
                  else if(jiaflag==1)
                  {
                      pid2.velo_i+=scales;
                      jiaflag=0;
                  }break;
        case 7:
                  if(jianflag==1)
                  {
                      pid2.angle_d-=scales;
                      jianflag=0;
                  }
                  else if(jiaflag==1)
                  {
                      pid2.angle_d+=scales;
                      jiaflag=0;
                  }
            break;
        case 8:
                  if(jianflag==1)
                  {
                      pid2.speed_I-=scales;
                      jianflag=0;
                  }
                  else if(jiaflag==1)
                  {
                      pid2.speed_I+=scales;
                      jiaflag=0;
                  }
            break;
        default:
         break;
    }
}

}
void menu1()
{
    tftclead();



}
void menu1aim()
{
    if(jianflag==1)
    {
        keythreshold-=2;
        jianflag=0;
    }else if(jiaflag==1)
    {
        keythreshold+=2;
        jiaflag=0;
    }
}
void menu2()
{tftclead();
ips200_show_string(0*8,0*16,"ZUO2:");
ips200_show_string(0*8,1*16,"ZUO1:");
ips200_show_string(0*8,2*16,"YOU1:");
ips200_show_string(0*8,3*16,"YOU2:");
ips200_show_string(0*8,4*16,"CBH:");
ips200_show_string(0*8,5*16,"ADC:");


}
void menu2aim()
{
            if(jianflag==1)
            {

                jianflag=0;
            }else if(jiaflag==1)
            {
                jiaflag=0;
            }

}
void tftclead()
{
    if(clearflag==0)
    {
        ips200_clear();
        clearflag=1;
    }
}

int Select_Mode=0;

void Modify_PID(void)
{
    //��Ļ��ʾ����
//    if(switch_flag==1){switch_flag=0;TFTSPI_CLS(u16BLACK);}  //����ҳ��


    Show_Main();

    int key1_flag=0;
    int key2_flag=0;
    int key3_flag=0;
    int key4_flag=0;

    if (key_get_state(KEY_1) == KEY_SHORT_PRESS)
    {
      keyflag[1] = 1;
    }
    else if (key_get_state(KEY_1) == KEY_RELEASE)
    {
      if (keyflag[1]==1)
      {
          key1_flag=1;
          keyflag[1] = 0;
      }
    }
    if (key_get_state(KEY_2) == KEY_SHORT_PRESS)
    {
      keyflag[2] = 1;
    }
    else if (key_get_state(KEY_2) == KEY_RELEASE)
    {
      if (keyflag[2]==1)
      {
          key2_flag=1;
          keyflag[2] = 0;
      }
    }
    if (key_get_state(KEY_3) == KEY_SHORT_PRESS)
    {
      keyflag[3] = 1;
    }
    else if (key_get_state(KEY_3) == KEY_RELEASE)
    {
      if (keyflag[3]==1)
      {
          key1_flag=1;
          keyflag[3] = 0;
      }
    }
    if (key_get_state(KEY_4) == KEY_SHORT_PRESS)
    {
      keyflag[4] = 1;
    }
    else if (key_get_state(KEY_4) == KEY_RELEASE)
    {
      if (keyflag[4]==1)
      {
          key4_flag=1;
          keyflag[4] = 0;
      }
    }

    if(key1_flag)
    {
        key1_flag=0;
        switch(Select_Mode)
        {
            case 0:  //P
                pid2.speed_p++;
                break;
            case 1:  //I
                pid2.speed_I++;
                break;
            case 2:
                pid2.speed_D++;
                break;
        }

    }
    else if(key2_flag)
    {
        key2_flag=0;
        switch(Select_Mode)
        {
            case 0:  //P
                pid2.speed_p--;
                break;
            case 1:  //I
                pid2.speed_I--;
                break;
            case 2:
                pid2.speed_D--;
                break;
        }


    }
    else if(key3_flag)  //ѡ���P���ǻ���D
    {
        key3_flag=0;
        Select_Mode++;
        if(Select_Mode>=2){Select_Mode=2;}

    }
    else if(key4_flag)  //ѡ���Servo����Motor
    {
        key4_flag=0;
        Select_Mode--;
        if(Select_Mode<=0){Select_Mode=0;}

    }

}


void Show_Main(void)
{
    char txt[40];
    sprintf(txt, "sp:%.4f ",pid2.speed_p);
    ips200_show_string(20,0,txt);
    sprintf(txt, "si:%.4f ",pid2.speed_I);
    ips200_show_string(20,20,txt);
    sprintf(txt, "sd:%.4f ",pid2.speed_D);
    ips200_show_string(20,40,txt);
//    sprintf(txt, "sp:%.4f ",pid2.speed_p);
//    ips200_show_string(0,0,txt);
//    sprintf(txt, "sp:%.4f ",pid2.speed_p);
//    ips200_show_string(0,0,txt);
//    sprintf(txt, "sp:%.4f ",pid2.speed_p);
//    ips200_show_string(0,0,txt);
//    sprintf(txt, "sp:%.4f ",pid2.speed_p);
//    ips200_show_string(0,0,txt);
//    sprintf(txt, "sp:%.4f ",pid2.speed_p);
//    ips200_show_string(0,0,txt);
//    sprintf(txt, "sp:%.4f ",pid2.speed_p);
//    ips200_show_string(0,0,txt);
    switch(Select_Mode)
    {
        case '0':ips200_show_string(0,0,'+++');break;
        case '1':ips200_show_string(0,20,'+++');break;
        case '2':ips200_show_string(0,40,'+++');break;
//        case '3':ips200_show_string(0,60,'+');break;
//        case '4':ips200_show_string(0,80,'+');break;
//        case '5':ips200_show_string(0,100,'+');break;
//        case '6':ips200_show_string(0,120,'+');break;
//        case '7':ips200_show_string(0,140,'+');break;
//        case '8':ips200_show_string(0,160,'+');break;
//        case '9':ips200_show_string(0,180,'+');break;

    }

}

