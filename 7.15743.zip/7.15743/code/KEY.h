#ifndef KEY_H
#define KEY_H

#include "zf_common_headfile.h"
extern int speedset,jiasuspeed,keycai,keythreshold,shunxu[],anspeed;
void keycaidan(void);
void menu0(void);
void menu0aim(void);
void menu1(void);
void menu1aim(void);
void menu2(void);
void menu2aim(void);
void tftclead(void);
void Modify_PID(void);
void Show_Main(void);

void handleKeyRelease(int key);
#endif /* CODE_ZW_UI_H_ */
