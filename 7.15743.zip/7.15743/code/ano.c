#include "ano.h"

#include "zf_driver_uart.h"

dt_flag_t    f;                                  //��Ҫ�������ݵı�־
uint8_t      data_to_send[100];                  //�������ݻ���
uint8_t      USART_RX_DATA[USART_RX_LEN];        //�������ݻ���

/* ������һ���ֽڵ����ݲ�ֳɶ���ֽڷ��� */
#define BYTE0(dwTemp)       ( *( (char *)(&dwTemp)    ) )
#define BYTE1(dwTemp)       ( *( (char *)(&dwTemp) + 1) )
#define BYTE2(dwTemp)       ( *( (char *)(&dwTemp) + 2) )
#define BYTE3(dwTemp)       ( *( (char *)(&dwTemp) + 3) )




/* ��������λ�����ʹ�����ԭʼ���� */
void ANO_DT_Send_User(int16_t user1,int16_t user2,int16_t user3,int16_t user4,int16_t user5,
                      float user6, float user7, float user8, float user9, float user10,
                      float user11,float user12,float user13,float user14,float user15)
{
  uint8_t _cnt=0;
  volatile int16_t _temp;
  float _temp_f;

  uint8_t sum = 0;
  uint8_t i=0;
  data_to_send[_cnt++]=0xAA;
  data_to_send[_cnt++]=0xAA;
  data_to_send[_cnt++]=0xF1;
  data_to_send[_cnt++]=0;

  //1-5  int16t��������
  _temp = user1;
  data_to_send[_cnt++]=BYTE1(_temp);
  data_to_send[_cnt++]=BYTE0(_temp);

  _temp = user2;
  data_to_send[_cnt++]=BYTE1(_temp);
  data_to_send[_cnt++]=BYTE0(_temp);
  _temp = user3;
  data_to_send[_cnt++]=BYTE1(_temp);
  data_to_send[_cnt++]=BYTE0(_temp);
  _temp = user4;
  data_to_send[_cnt++]=BYTE1(_temp);
  data_to_send[_cnt++]=BYTE0(_temp);
  _temp = user5;
  data_to_send[_cnt++]=BYTE1(_temp);
  data_to_send[_cnt++]=BYTE0(_temp);

  //6-10 ��float��������
  _temp_f = user6;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);
  _temp_f = user7;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);
  _temp_f = user8;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);
  _temp_f = user9;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);
  _temp_f = user10;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);

  _temp_f = user11;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);
  _temp_f = user12;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);
  _temp_f = user13;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);
  _temp_f = user14;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);
  _temp_f = user15;
  data_to_send[_cnt++]=BYTE3(_temp_f);
  data_to_send[_cnt++]=BYTE2(_temp_f);
  data_to_send[_cnt++]=BYTE1(_temp_f);
  data_to_send[_cnt++]=BYTE0(_temp_f);

  data_to_send[3] = _cnt-4;

  sum = 0;
  for(i=0;i<_cnt;i++)
      sum += data_to_send[i];
  data_to_send[_cnt++] = sum;

  uart_write_buffer(UART_0,data_to_send,_cnt);//�������TC264DMAͨ���������ݾͺ���
}

